CREATE DATABASE  IF NOT EXISTS `homedong` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `homedong`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: i5a608.p.ssafy.io    Database: homedong
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT COMMENT '사용자 id',
  `nickname` varchar(10) NOT NULL COMMENT '닉네임',
  `email` varchar(50) NOT NULL COMMENT '이메일',
  `password` varchar(200) NOT NULL COMMENT '비밀번호',
  `is_tutorial_finished` tinyint(1) NOT NULL DEFAULT '0' COMMENT '다시보지 않기',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '회원 가입 시간',
  `token` varchar(200) DEFAULT NULL COMMENT '소셜 로그인 토큰',
  `img` varchar(200) NOT NULL COMMENT '이미지',
  `auth_key` varchar(8) NOT NULL COMMENT '인증번호',
  `auth_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '인증여부',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb3 COMMENT='회원';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (99,'3대999','qlcid@naver.com','$2a$10$nUR5bjtg6fySJl5JDzUDXuD3vehcYAZshJwlt5X4W7NGsqdzTA8jy',0,'2021-08-19 01:33:32',NULL,'2','I7caV1',1),(100,'김성민','kimsm4524@naver.com','$2a$10$.gsDNie.0qUDTwKl/x7eoO5ulc6xKXjrrR.x2Lz7A7jPiqGROM1Xq',0,'2021-08-19 01:33:34',NULL,'10','3TeHdl',1),(101,'김싸피123','ssmin940606@gmail.com','$2a$10$cddqKjf5hH38WsvcsJwYOu.VCHGOxHkjGJzwafLakVm6uDp7/11hC',0,'2021-08-19 01:40:15',NULL,'13','dDgXuN',0),(102,'최인국교수','c_admin@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 01:41:14',NULL,'6','123456',1),(103,'신상훈코치','s_admin@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 01:41:15',NULL,'7','123457',1),(104,'일반교수','c_test@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 01:41:15',NULL,'16','123458',1),(105,'일반코치','s_test@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 01:41:15',NULL,'9','123459',1),(106,'영으니당','yesfordev@gmail.com','$2a$10$9U2yIZbt28NtEGcb4S8nQOxSpFTyWTTw75kScBrBSfdgTUefcdkjO',0,'2021-08-19 03:10:13',NULL,'23','MY6XzC',1),(110,'안녕','t1@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:11:44',NULL,'5','120000',1),(111,'힘들어','t2@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:12:08',NULL,'6','120001',1),(112,'릴렉스','t3@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:12:42',NULL,'7','120002',1),(113,'돼지살빼다','t4@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:13:03',NULL,'7','120003',1),(114,'닉네임인데요','t5@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:13:21',NULL,'7','120004',1),(115,'저아세요','t6@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:00',NULL,'8','120005',1),(116,'홈동입니다','homedong@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:08',NULL,'20','Pdsfsa',1),(117,'홈동굿','homedong2@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:08',NULL,'11','Pdsfs1',1),(118,'안녕홈동','homedong3@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:08',NULL,'14','Pdrds2',1),(119,'홈동재미있어','homedong4@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:08',NULL,'12','Pddljs',1),(120,'홈동헷','homedong5@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:08',NULL,'20','sdfaP3',1),(121,'오재미있다','homedong6@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:08',NULL,'1','w2djOs',1),(122,'굿굿','homedong7@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:08',NULL,'23','dklsP1',1),(123,'누구세요','t7@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:34',NULL,'7','120006',1),(124,'홈동개쩔어','t8@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:14:58',NULL,'8','120008',1),(125,'홈동킹동','t9@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:15:21',NULL,'9','120009',1),(126,'홈동잉','homedong8@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:17:47',NULL,'15','dkssP1',1),(127,'홈동23','homedong9@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:22:06',NULL,'22','Pdsfsa',1),(128,'홈동스','homedong10@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:24:11',NULL,'20','MY6XzC',1),(129,'홈동킹1동','tt@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 07:49:16',NULL,'19','120599',1),(130,'히히히','sakwook2@naver.com','$2a$10$LApR.gxDzlSzWcfFwM2qFOelvVSGPJIbKqGkmVIBQgepACW84u1ci',0,'2021-08-19 08:16:38',NULL,'8','v7a5ry',1),(131,'123123','ssmin0606@hanmail.net','$2a$10$2zIlWn74v/hAWEMOvZdukeC8HTsVWIdflIYsTtI9I3.FSxWAz636C',0,'2021-08-19 12:24:22',NULL,'5','4SEu6i',0),(132,'영은231','yesfordev@gmail','$2a$10$67kmjMeSrTOeowxo4kWB4.zg92o8R5Wrz74b3mtGB9wWT.rDOYOFy',0,'2021-08-19 12:40:30',NULL,'5','rpdJqg',0),(133,'3대800','ttt@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 15:03:39',NULL,'2','130050',1),(134,'3대400','abc@naver.com','$2a$10$Pb2zSm5KnQfIzA5tloNFJ.RSpbM.2DnIkNu14TOfMmcPE5ntGis6S',0,'2021-08-19 15:04:40',NULL,'19','130350',1),(136,'오주년','oh.junhyeon95@gmail.com','$2a$10$ZuOF2OlCeCoa/DOjQD.CdOnA8002e0t4wd.L8wnybC6sLLbIC2njK',0,'2021-08-19 15:17:16',NULL,'8','s3268T',1),(137,'성민아자냐','wkeo@naver.com','$2a$10$mL.tP4hAy4DDOBOm07Qbp.fTy1L90jDfUiSgn4GEOW0o/DiPfpBfq',0,'2021-08-19 16:18:43',NULL,'15','tDxAVI',1),(139,'12313','ssmin2940606@gmail.com','$2a$10$7DbNNBe4Hq1K5eqOFxuNRO3dFIDrYk3RHp5zBVoJ0.SSZ3.yab6si',0,'2021-08-20 00:45:15',NULL,'7','AmFG8N',0),(143,'wdwd','sam606@naver.com','$2a$10$b1HRh6Lup3iQN3rNoM2aL.Tr7aExWwXZAs9lmLKkDgnUUqGrNg5gq',0,'2021-08-20 01:22:33',NULL,'8','WMWt0l',1),(145,'홈동짱','homedong.calisthenics@gmail.com','$2a$10$AfCSWljAvrZF6oY12xzQceevPI/pTP0yhVM1alPeQ3c6VbJgVNzaO',0,'2021-08-20 02:01:25',NULL,'22','yrcyhV',1),(147,'123','sssmin940606@gmail.com','$2a$10$N9SFU0XeGn9p1LDtZyEJUemSppYWSgFl61Qe3wWM9aOvmT0nA9Wvy',0,'2021-08-20 02:02:32',NULL,'13','oDK0LC',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:12:05
